<?php 
namespace Modules\Seo\Exports;
 

use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;
use Modules\Seo\Models\WorkReport;
use Modules\Seo\Models\SeoSubmissionWebsites;
 
class WorkReportExport implements FromCollection,WithHeadings
{

     public function __construct(  $startdate,   $enddate, $website_id) 
        {
            $this->startdate = $startdate;
            $this->enddate = $enddate;
            $this->website_id = $website_id;
        }

    /**
    * @return \Illuminate\Support\Collection
    */ 
    public function headings():array{
        return[
           // 'Task',
            // 'Website Url',
            // 'Posting URL',
            // 'Landing URL',
            // 'Date',
            'Date',
            'Website URL',
            'Landing URL',
            'Submission Website',
            'Email',
            'User Name',
            'Password',
            'DA',
            'Spam Score',
            'Linktype'
        ];
    } 

    public function collection()
    {

         $work_report = WorkReport::with('SeoSetting','SubmissionWebsite')->select("seo_work_report.*")->wherebetween('submission_date', [$this->startdate, $this->enddate])->where('website_id',$this->website_id)->get();


          $work_data = collect([]);

        foreach($work_report as $work){

            // $seo_submission = SeoSubmissionWebsites::where('id' , $work->submission_websites_id)->first();

            $work_data->add([
                "date" => $work->submission_date,
                "website_url" => $work->SubmissionWebsite->website_url ?? '',
                "landing_url" => $work->landing_url,
                "submission_website" => $work->url,
                "Email" => $work->SubmissionWebsite->email  ?? '',
                "user_name" => $work->SubmissionWebsite->username ?? '',
                "password" => $work->SubmissionWebsite->password ?? '',
                "da" => $work->SubmissionWebsite->da ?? '',
                "spam_score" => $work->SubmissionWebsite->spam_score ?? '',
                "linktype" => $work->linktype,                
             ]);

        } 

         return $work_data;
          
    }
}