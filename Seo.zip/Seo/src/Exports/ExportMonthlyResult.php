<?php 
namespace Modules\Seo\Exports;

use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;
use Modules\Seo\Models\SeoTitle;
use DB;
 
class ExportMonthlyResult implements FromCollection,WithHeadings
{

     public function __construct(  $website,   $month, $year) 
        {
            $this->website = $website;
            $this->month = $month;
            $this->year = $year;
        }

    /**
    * @return \Illuminate\Support\Collection
    */ 
    public function headings():array{
        return[
            'Title',
            'Sub Title',
            'Result',
        ];
    } 

    public function collection()
    {

         $seo_result = array();
        $seo_result = DB::table('seo_website_result')
            ->select('id','result_title_id', 'result_value')
            ->where([
                "website_id" =>$this->website,
                "month" =>   $this->month,
                "year" => $this->year
            ])
            ->get();
           

        $result_array = array();
        if (!empty($seo_result)) {
            foreach ($seo_result as $result) {
                $result_array[$result->result_title_id] = $result->result_value;
            }
        }


        // GET PARENT TITLE
        $seo_title = SeoTitle::select('id', 'title_name', 'parent_id', 'status', 'created_at')
            ->OrderBy('sort_order', 'asc')
            ->where('parent_id', 0)
            ->get();

        // GET CHILD TITLE
        if (!empty($seo_title)) {
            $seo_title = $seo_title->map(function ($title) {

                $title->child = SeoTitle::where('parent_id', $title->id)->get();

                return $title;
            });
        }

        $data['seo_title'] = $seo_title;
        $data['seo_result'] = $result_array;


         $result = collect([]);

         if(!empty($seo_title)){

        foreach($seo_title as $seo){
            foreach($seo->child as $child){
                 $result->add([
                    "title" => $seo->title_name,
                    "subtitle" => $child->title_name ?? '',
                    "result" => $result_array[$child->id] ?? '',
                 ]);
            }
        }
        }


        return $result;

         
               
    }
}