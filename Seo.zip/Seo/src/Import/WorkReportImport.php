<?php
namespace Modules\Seo\Import;

use Date;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Modules\Seo\Models\SeoSubmissionWebsites;
use Modules\Seo\Models\WorkReport;

class WorkReportImport implements ToModel, WithHeadingRow
{

    public function __construct($website_id, $seo_task_id, $user_id)
    {
        $this->website_id = $website_id;
        $this->seo_task_id = $seo_task_id;
        $this->user_id = $user_id;
    }

    public function model(array $row)
    {

        if(!empty($row)){
            $match_data = SeoSubmissionWebsites::where(['website_url' => $row['submission_website'], 'website_id' => $this->website_id, 'seo_task_id' => $this->seo_task_id])->first();

            // $date = Carbon::parse($row['submission_date'])->format('d-m-Y');

            $date = date('Y-m-d', strtotime($row['date']));

            if($row['submission_website'] != ''){

                if (empty($match_data)) {
                    $submission = SeoSubmissionWebsites::create([
                        "website_id" => $this->website_id,
                        "seo_task_id" => $this->seo_task_id,
                        "website_url" => $row['submission_website'],
                        "username" => $row['user_name']?? null,
                        "username" => $row['email']?? null,
                        "password" => $row["password"],
                        'da' => $row['da'] ?? null,
                        'spam_score' => $row['spam_score'] ?? null,
                        "created_by" => $this->user_id,

                    ]);

                    if (!empty($submission)) {
                        $linktype = ($row['linktype']=='Dofollow')? 1 : ( ($row['linktype'] =='Nofollow')? 2 : 0 );
                        $work_report = WorkReport::create([
                            'landing_url' => $row['landing_url'],
                            'url' => $row['website_url'],
                            'linktype' => $linktype,
                            'website_id' => $this->website_id,
                            'user_id' => $this->user_id,
                            'seo_task_id' => $this->seo_task_id,
                            'submission_websites_id' => $submission->id,
                            'submission_date' => $date,
                        ]);
                    }

                    return $submission;

                } else {

                    $data = WorkReport::where('landing_url', $row['landing_url'])->where('url', $row['website_url'])->where('website_id', $this->website_id)->where('seo_task_id', $this->seo_task_id)->where('submission_websites_id', $match_data->id)->first();

                    if (empty($data)) {
                        if (!empty($match_data)) {
                            $work_report = WorkReport::create([
                                'url' => $row['website_url'],
                                'landing_url' => $row['landing_url'],
                                'website_id' => $this->website_id,
                                'user_id' => $this->user_id,
                                'seo_task_id' => $this->seo_task_id,
                                'submission_websites_id' => $match_data->id,
                                'submission_date' => $date,
                            ]);

                            return $work_report;
                        }
                    }

                }
            }
        }

    }
}
