<?php
namespace Modules\Seo\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use App\Models\User;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use Modules\Seo\Exports\WorkReportExport;
use Modules\Seo\Import\WorkReportImport;
use Modules\Seo\Models\SeoTask;
use Modules\Seo\Models\Website;
use Modules\Seo\Models\WorkReport;

class SeoReportController extends Controller
{
    public $page = 'work_report';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $seo_task = Website::get();

        /*Binding data into a variable*/

        $res = [
            'seo_task' => $seo_task,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');

    }

    public function importAdd(Request $request)
    {
        $api_token = $request->api_token;

        $user_list = User::all();
        $seo_task_list = SeoTask::all();
        $website_list = Website::all();

        $res = [
            'user_list' => $user_list,
            'seo_task_list' => $seo_task_list,
            'website_list' => $website_list,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');

    }

    public function importStore(Request $request)
    {
        $api_token = $request->api_token;
        $user = User::where('api_token', $request->api_token)->first();

        
        $import_file = $request->file('import_file');
        
        if (!empty($import_file)) {

             Excel::import(new WorkReportImport($request->website_id, $request->seo_task_id, $user->id),  $request->file('import_file'));

            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_WORK_REPORT_IMPORT');

            if ($sheetData) {
                return ApiHelper::JSON_RESPONSE(true, $sheetData, 'SUCCESS_WORK_REPORT_IMPORT');
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_WORK_REPORT_IMPORT');
            }

        }

    }

    public function work_report(Request $request)
    {
        $api_token = $request->api_token;
        $startdate = $request->startdate;
        $enddate = $request->enddate;
        $website_id = $request->website_id;
        $todayDate = date("Y-m-d");

        // current date by default
        if (($request->startDate == $todayDate) && ($request->website_id == 0)) {
            $work_report = WorkReport::with('SeoSetting', 'SubmissionWebsite')->select("seo_work_report.*")->whereDate('submission_date', Carbon::today())->get();

        }

        //selected date

        if (($startdate != null && $enddate != null && $website_id == 0)) {

            $work_report = WorkReport::with('SeoSetting', 'SubmissionWebsite')->select("seo_work_report.*")
                ->wherebetween('submission_date', [$startdate, $enddate])
                ->orWhereDate('submission_date', $startdate)->orWhereDate('submission_date', $enddate)->get();

            $seo_task = SeoTask::all();
            $data['work_report'] = $work_report;
            $data['seo_task'] = $seo_task;

            return ApiHelper::JSON_RESPONSE(true, $data, '');

        }

        // select date and website
        if ($startdate != null && $enddate != null && $website_id != 0) {
            $work_report = WorkReport::with('SeoSetting', 'SubmissionWebsite')->where('website_id', $website_id)->whereBetween(DB::raw("(DATE_FORMAT(submission_date,'%Y-%m-%d'))"), [$startdate, $enddate])->get();
        }

        // if($website_id == 0 && ){

        //     $work_report = WorkReport::with('SeoSetting','SubmissionWebsite')->get();
        // }

        $seo_task = SeoTask::all();
        $data['work_report'] = $work_report;
        $data['seo_task'] = $seo_task;

        return ApiHelper::JSON_RESPONSE(true, $data, '');

    }

    public function exportData(Request $request)
    {

        $startdate = $request->startdate;
        $enddate = $request->enddate;
        $website_id = $request->website_id;

        $name = 'work_report_' . date('Y-m-d i:h:s');

        $data = Excel::store(new WorkReportExport($startdate, $enddate, $website_id), $name . '.xlsx');

        $url = Storage::path($name . '.xlsx');

        return ApiHelper::JSON_RESPONSE(true, $url, '');

    }

}
