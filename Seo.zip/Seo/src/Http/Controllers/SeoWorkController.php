<?php
namespace Modules\Seo\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Modules\Seo\Models\SeoMonthlyStrategy;
use Modules\Seo\Models\SeoSubmissionWebsites;
use Modules\Seo\Models\SeoTask;
use Modules\Seo\Models\Website;
use Modules\Seo\Models\WorkReport;
use Auth;
use Validator;



class SeoWorkController extends Controller
{
    public $page = 'daily_work';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    //This Function is used to show the list
    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $countrylist = Country::all();
        $seo_task_listing = SeoTask::all();
        $website_listing = Website::all();

        if (!empty($website_listing)) {
            $countryData = $website_listing->map(function ($countrylist) {
                $countrylist->parentName = Country::where('countries_id', $countrylist->countries_id)->get();

                return $countrylist;
            });
        }

        //find subscription_id in user
        $subscription_id = ApiHelper::get_subscription_id_by_api_token($api_token);
        $web_setting_list = Website::where('subscription_id', $subscription_id)->first();

        /*Binding data into a variable*/

        $res = [
            'countrylist' => $countrylist,
            'seo_task_listing' => $seo_task_listing,
            'website_listing' => $website_listing,
            'web_setting_list' => $web_setting_list,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        //

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;

        $user_id = ApiHelper::get_user_id_from_token($api_token);

        

        $today_date = $seo_task_listing = $website_listing = '';

        if ($request->id) {
            $website_listing = Website::find($request->id);
            $website_name = $website_listing->website_name;

            $today_date = Carbon::today()->toDateString();

            $seo_task_listing = SeoMonthlyStrategy::with('Seotaskresult')->where('status', '1')->where('website_id', $request->id)->get();

            //$seo_task_listing = SeoTask::where('status', '1')->get();

            if (!empty($seo_task_listing)) {
                $seo_task_listing->map(function ($seo) use ($website_listing, $today_date ,$user_id) {

                    $seo->website_submission = SeoSubmissionWebsites::where('website_id', '=', $website_listing->id)->where('seo_task_id', $seo->seo_task_id)->get();

                    $seo->work_report = WorkReport::where('website_id', '=', $website_listing->id)->where('seo_task_id', $seo->seo_task_id)->where('submission_date', $today_date)->where('user_id' , $user_id)->get();
                    
                    return $seo;
                });
            }
        }

        $seotask=SeoTask::all();
        $websites = Website::all();

        $res = [
            'today_date' => $today_date,
            'seo_task_listing' => $seo_task_listing,
            'website_listing' => $website_listing,
            'website_name' => $website_name,
            'seotask' => $seotask,
            'websites' => $websites
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {

        //

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {

        //
    }

    public function dailyWorkStatus(Request $request)
    {
        $api_token = $request->api_token;

        $website = Website::where('id', $request->website_id)->first();
        $website->status = $request->status;
        $website->update();

        return ApiHelper::JSON_RESPONSE(true, $website, 'SUCCESS_STATUS_UPDATE');

    }

    public function work_report_update(Request $request)
    {
        //     // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $api_token = $request->api_token;

        $user_id = ApiHelper::get_user_id_from_token($api_token);

        

        $id = $request->id;

        $website_id = $request->website_id;

        $total_report = $request->total_report;

        $user = User::where('api_token', $request->api_token)->first();

        for ($i = 1; $i <= $total_report; $i++) {

            if ($request->input('website_url_' . $i) != null) {

                $update_id = ($request->input('update_id_' . $i)) ?? 0;
                $website_url = $request->input('website_url_' . $i);
                $landing_url = $request->input('landing_url_' . $i);
                $submission_url = $request->input('postingWebsite_' . $i);
                $do_follow = $request->input('do_follow_' . $i);

                //return ApiHelper::JSON_RESPONSE(true, $landing_url, 'SUCCESS_WORK_REPORT_UPDATE');

                $data = WorkReport::where('landing_url', $landing_url)->where('url', $website_url)->where('website_id', $request->website_id)->where('seo_task_id', $request->seo_task_id)->where('submission_websites_id', $submission_url)->where('submission_date', Carbon::now())->first();
                if($do_follow == "on"){
                    $d_follow = 1;
                }else{
                    $d_follow = 0;
                }

                if (empty($data)) {
                    if(!empty($landing_url)){
                        $workReport = WorkReport::updateOrCreate(
                            ['id' => $update_id],
                            [
                                'user_id' => $user->id,
                                'website_id' => $request->website_id,
                                'seo_task_id' => $request->seo_task_id,
                                'submission_websites_id' => $submission_url,
                                'url' => $website_url,
                                'landing_url' => $landing_url,
                                'submission_date' => Carbon::now(),
                                'linktype' => $d_follow

                            ]);

                    

                        
                    }
                }
            }
        }


        if ($workReport) {
            return ApiHelper::JSON_RESPONSE(true, $workReport, 'SUCCESS_WORK_REPORT_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_WORK_REPORT_UPDATE');
        }

    }


    public function postingupdate(Request $request){

        $seotask=SeoTask::all();
        $websites = Website::all(); 

        $res = [
            'seotask'=>$seotask,
            'websites' =>$websites,
            'task_id' => $request->task_id,
            'web_name' => $request->web_name,
            
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_WORK_REPORT_UPDATE');

    }


    public function postingstore(Request $request){

        $api_token = $request->api_token;
        
            $validator = Validator::make($request->all(),[
                'username'=> 'required',
                'website_id'=> 'required',
                'password'=> 'required',
                'do_follow'=>'required',
            ],
                [
                    
                'username.required'=>'WEBSITE_USERNAME_REQUIRED',
                'website_id.required'=>'WEBSITE_ID_REQUIRED',
                'password.required'=>'WEBSITE_PASSWORD_REQUIRED',
                'password.do_follow'=>'DO_FOLLOW_REQUIRED',

                ]

            );

            if ($validator->fails())
                return ApiHelper::JSON_RESPONSE(false,[],$validator->messages());


            $user = User::where('api_token', $request->api_token)->first();

            $website_url = SeoSubmissionWebsites::where('website_url' , $request->website_url)->first();

            if($website_url){
                return ApiHelper::JSON_RESPONSE(false, [], 'WEBSITE_URL_ALREADY_EXIST');
            }


            $data= SeoSubmissionWebsites::create([
                'website_id'=>$request->website_id,
                'seo_task_id'=>$request->seo_task_id,
                'website_url'=>$request->website_url,
                'username'=>$request->username,
                'email'=>$request->email,
                'password'=>$request->password,
                'dofollow' =>$request->do_follow,
                'da'=>$request->da,
                'spam_score'=>$request->spam_score,
                'status'=> 1,
                'created_by' => $user->id,
            ]);

           

            if ($data) {
                return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SUBMISSION_ADD');
            } else {
                return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SUBMISSION_ADD');
            }

    }

   

}
