<?php
namespace Modules\Seo\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  Auth;
use Modules\Seo\Models\SeoTask; 
use Modules\Seo\Models\Website;
use Modules\Seo\Models\SeoTitle;
use Modules\Seo\Models\SeoWebsiteResult;
use App\Models\Country;
use Carbon\Carbon;
use Modules\Seo\Models\SeoSubmissionWebsites;
use Modules\Seo\Models\WorkReport;
use DB;
use ApiHelper;
use Modules\Seo\Exports\ExportMonthlyResult;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Storage;
use App\Models\User;

class SeoResultController extends Controller
{
    
    public function index(Request $request)
    {
        $api_token = $request->api_token;
        $web_setting = Website::get();

        //find subscription_id in user
        $subscription_id= ApiHelper::get_subscription_details_by_api_token($api_token); 
        
        //$web_setting_list=Website::where('subscription_id', $subscription_id->subscription_id)->first();

          


        $seotitle = SeoTitle::OrderBy('sort_order', 'asc')->where('parent_id', 0)->get();
        
        $now = Carbon::now();
       

        $year = $now->format('Y');
        $month = $now->format('m');
       
        $yeardata = Carbon::now()->addYear(28);
        $addyear = $yeardata->format('Y');

        $subdata = Carbon::now()->subYear(10);
        $subyear = $subdata->format('Y');
       

        /*Binding data into a variable*/

        $res = [
            'web_setting'=>$web_setting,
            //'web_setting_list'=>$web_setting_list,
            'seotitle' =>$seotitle,
            'year' =>$year,
            'month' =>$month,
            'addyear' =>$addyear,
            'subyear' =>$subyear,
            
        ];


        return ApiHelper::JSON_RESPONSE(true,$res,'');
    }

 
    public function store(Request $request)
    {
        $api_token = $request->api_token;
        
        if(!empty($request->website_id)){
        
        if($request->title_id != null){    
            $title_id=$request->title_id;
            
            foreach($title_id as $key=>$value){
                $result_value=$request->result_value;
                $data = SeoWebsiteResult::updateOrCreate([
                    'website_id'     =>$request->website_id,
                    'result_title_id'=>$value,
                    'month'          =>  $request->month,
                    'year'           =>  $request->year,
                    ],
                    [ 
                        'result_value'=>$result_value[$key] ?? '',
                       
                    ]);
            }
        }else{
            return ApiHelper::JSON_RESPONSE(true, [], 'NO_ANY_DATA_UPDATE');
        }
           
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_MONTHLY_RESULT_UPDATE');
            

           
        }
          
       else{
            return ApiHelper::JSON_RESPONSE(false, $data, 'ERROR_MONTHLY_RESULT_UPDATE');
       }

    }

    


    public function getMonthlyResult(Request $request)
    {

        $api_token = $request->api_token;
        
        $seo_result = array();
        $seo_result = DB::table('seo_website_result')
            ->select('id','result_title_id', 'result_value')
            ->where([
                "website_id" => $request->website_id,
                "month" => $request->month,
                "year" => $request->year
            ])
            ->get();
           

        $result_array = array();
        if (!empty($seo_result)) {
            foreach ($seo_result as $result) {
                $result_array[$result->result_title_id] = $result->result_value;
            }
        }


        // GET PARENT TITLE
        $seo_title = SeoTitle::select('id', 'title_name', 'parent_id', 'status', 'created_at')
            ->OrderBy('sort_order', 'asc')
            ->where('parent_id', 0)
            ->get();

        // GET CHILD TITLE
        if (!empty($seo_title)) {
            $seo_title = $seo_title->map(function ($title) {

                $title->child = SeoTitle::where('parent_id', $title->id)->get();

                return $title;
            });
        }

        $data['seo_title'] = $seo_title;
        $data['seo_result'] = $result_array;


        return ApiHelper::JSON_RESPONSE(true,$data,'');


    }


    public function exportMonthlyResult(Request $request){

        $website = $request->website;
        $month = $request->month;
        $year = $request->year;



        $api_token = $request->api_token;

        $seo_result = array();
        $seo_result = DB::table('seo_website_result')
            ->select('id','result_title_id', 'result_value')
            ->where([
                "website_id" => $website,
                "month" => $month,
                "year" => $year
            ])
            ->get();
           

        $result_array = array();
        if (!empty($seo_result)) {
            foreach ($seo_result as $result) {
                $result_array[$result->result_title_id] = $result->result_value;
            }
        }


        // GET PARENT TITLE
        $seo_title = SeoTitle::select('id', 'title_name', 'parent_id', 'status', 'created_at')
            ->OrderBy('sort_order', 'asc')
            ->where('parent_id', 0)
            ->get();

        // GET CHILD TITLE
        if (!empty($seo_title)) {
            $seo_title = $seo_title->map(function ($title) {

                $title->child = SeoTitle::where('parent_id', $title->id)->get();

                return $title;
            });
        }

        $data['seo_title'] = $seo_title;
        $data['seo_result'] = $result_array;

        foreach ($seo_title as $key => $parentData) {
            foreach ($parentData->child as $childkey => $child) {

                if($result_array != null){
                     $name = 'monthly_result_' . '0' .$request->month . '-' . $request->year;

                    $data = Excel::store(new ExportMonthlyResult($website , $month , $year), $name . '.xlsx');

                    $url = Storage::path($name . '.xlsx');

                    return ApiHelper::JSON_RESPONSE(true,$url,'');
                }else{
                    return ApiHelper::JSON_RESPONSE(false,'','RESULT_VALUE_NOT_EXIST');
                }

            }
        }


        


        
       

    }
   
  

}
